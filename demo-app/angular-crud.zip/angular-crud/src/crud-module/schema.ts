
export interface MenuOptions {
    name: string;
    appRoot: string;
    path: string;
    sourceDir: string;

    module: string;
    export: boolean;

    model: string;
}